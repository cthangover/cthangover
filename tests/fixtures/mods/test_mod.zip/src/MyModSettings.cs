using System.Collections.Generic;
using Cthangover.Core.Mods;
using Cthangover.Core.Settings;

public class MyModSettings : IModSettings
{
    private float _explosionRadius = 1.5f;
    private bool _debugMode;

    public IReadOnlyList<ModSettingDefinition> GetDefinitions()
    {
        return new List<ModSettingDefinition>
        {
            new()
            {
                Key = "explosion_radius",
                Name = "mymod/explosion_radius",
                Type = SettingType.Slider,
                DefaultValue = "1.5",
                Min = 0.5f,
                Max = 10f,
                Step = 0.5f
            },
            new()
            {
                Key = "debug_mode",
                Name = "mymod/debug_mode",
                Type = SettingType.Bool,
                DefaultValue = "false"
            },
new()
{
    Key = "difficulty",
    Name = "mymod/difficulty",
    Type = SettingType.Enum,
    DefaultValue = "normal",
    Options = new Dictionary<string, string>
    {
        { "easy",   "mymod/diff_easy" },
        { "normal", "mymod/diff_normal" },
        { "hard",   "mymod/diff_hard" }
    }
}
        };
    }

    public void WriteValues(DataBlob blob)
    {
        blob.SetFloat("explosion_radius", _explosionRadius);
        blob.SetBool("debug_mode", _debugMode);
    }

    public void ReadValues(DataBlob blob)
    {
        _explosionRadius = blob.GetFloat("explosion_radius", 1.5f);
        _debugMode = blob.GetBool("debug_mode", false);
    }
}